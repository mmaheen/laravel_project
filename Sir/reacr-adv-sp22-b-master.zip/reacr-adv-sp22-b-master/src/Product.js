const Product =(props)=>{

    return(
        <div>
            <span>{props.Name}</span>
            <p>{props.Price}</p>
        </div>
    )
}
export default Product;