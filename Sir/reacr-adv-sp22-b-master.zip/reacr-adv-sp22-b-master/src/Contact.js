import Header from './Header';
const Contact =()=>{
    return(
        <div>
            
            <p>This is contact page</p>
        </div>
        
    )
}
export default Contact;